const db = require("../config/db");
const getGithubData = require("../services/githubService");

// Analyze GitHub Profile
const analyzeProfile = async (req, res) => {
  try {
    const username = req.params.username;

    const { user, repos } = await getGithubData(username);

    const totalStars = repos.reduce(
      (sum, repo) => sum + repo.stargazers_count,
      0
    );

    const sql = `
      INSERT INTO profiles
      (
        github_id,
        username,
        name,
        bio,
        followers,
        following,
        public_repos,
        total_stars,
        profile_url,
        avatar_url
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
      followers = VALUES(followers),
      following = VALUES(following),
      public_repos = VALUES(public_repos),
      total_stars = VALUES(total_stars)
    `;

    db.query(
      sql,
      [
        user.id,
        user.login,
        user.name,
        user.bio,
        user.followers,
        user.following,
        user.public_repos,
        totalStars,
        user.html_url,
        user.avatar_url
      ],
      (err) => {
        if (err) {
          console.log(err);
          return res.status(500).json({
            message: "Database Error"
          });
        }

        res.status(200).json({
          username: user.login,
          followers: user.followers,
          following: user.following,
          public_repos: user.public_repos,
          total_stars: totalStars
        });
      }
    );
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};

// Get All Profiles
const getAllProfiles = (req, res) => {
  db.query(
    "SELECT * FROM profiles ORDER BY analyzed_at DESC",
    (err, results) => {
      if (err) {
        return res.status(500).json({
          message: "Database Error"
        });
      }

      res.status(200).json(results);
    }
  );
};

// Get Single Profile
const getSingleProfile = (req, res) => {
  const username = req.params.username;

  db.query(
    "SELECT * FROM profiles WHERE username = ?",
    [username],
    (err, results) => {
      if (err) {
        return res.status(500).json({
          message: "Database Error"
        });
      }

      if (results.length === 0) {
        return res.status(404).json({
          message: "Profile Not Found"
        });
      }

      res.status(200).json(results[0]);
    }
  );
};

module.exports = {
  analyzeProfile,
  getAllProfiles,
  getSingleProfile
};