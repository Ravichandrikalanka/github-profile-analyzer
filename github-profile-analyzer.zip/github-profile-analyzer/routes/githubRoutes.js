const express = require("express");

const router = express.Router();

const {
  analyzeProfile,
  getAllProfiles,
  getSingleProfile
} = require("../controllers/githubController");

// Analyze GitHub User
router.get("/profile/:username", analyzeProfile);

// Get All Stored Profiles
router.get("/profiles", getAllProfiles);

// Get Single Profile
router.get("/profiles/:username", getSingleProfile);

module.exports = router;