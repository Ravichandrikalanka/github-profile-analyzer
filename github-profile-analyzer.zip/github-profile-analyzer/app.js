require("dotenv").config();

const express = require("express");
const cors = require("cors");

require("./config/db");

const githubRoutes = require("./routes/githubRoutes");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    message: "GitHub Profile Analyzer API Running"
  });
});

app.use("/api", githubRoutes);

app.listen(process.env.PORT, () => {
  console.log(`Server Running On Port ${process.env.PORT}`);
});